# Forj Carbon — Portfolio

Site une page. Dézipper et pousser tel quel sur GitHub, Netlify fait le reste.

```
index.html            le site complet
img/etape-01..05.jpg  les 5 étapes du projet aileron
img/mat-01..08.jpg    le matériel d'infusion
video/timelapse.mp4   le timelapse d'impression
```
